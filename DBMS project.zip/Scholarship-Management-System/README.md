# Scholarship & Student Disbursement Dashboard

A small Streamlit application for managing scholarship schemes, student applications, and disbursement records using a relational SQLite database.

## Features

- View scholarship schemes, student applications, and disbursements.
- Add a scholarship application and its disbursement in one database transaction.
- Delete schemes, applications, or individual disbursement records.
- View a combined report using SQL `JOIN`.
- Enforce relational integrity with SQLite foreign keys and cascading deletes.
- Explore educational explanations of database recovery concepts: Shadow Paging and ARIES.

## Technology stack

- Python
- Streamlit
- Pandas
- SQLite (Python standard library)

## Project files

```text
Scholarship-Management-System/
├── scholarship_dashboard.py   # Main Streamlit application
├── requirements.txt           # Python dependencies
├── .gitignore                 # Files excluded from Git
└── README.md                  # Project documentation
```

The SQLite database file (`scholarship_dashboard.db`) is created automatically beside the Python application when it runs. It is intentionally excluded from Git so that each user can create their own local database.

## Requirements

- Python 3.9 or newer
- pip

## Run locally

1. Clone the repository:

   ```bash
   git clone YOUR_GITHUB_REPOSITORY_URL
   cd Scholarship-Management-System
   ```

2. (Recommended) Create and activate a virtual environment:

   **Windows PowerShell**
   ```powershell
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

   **macOS / Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

3. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

4. Start the dashboard:

   ```bash
   streamlit run scholarship_dashboard.py
   ```

5. Open the local URL printed by Streamlit in your browser (usually `http://localhost:8501`).

## Database design

The application creates three related tables:

| Table | Purpose |
|---|---|
| `schemes` | Stores scholarship scheme names and coordinator email addresses. |
| `applications` | Stores student applications and links each application to a scheme. |
| `disbursements` | Stores disbursement type and amount for an application. |

Foreign keys connect applications to schemes and disbursements to applications. `ON DELETE CASCADE` is used so deleting a scheme also deletes its related applications and disbursements, while deleting an application removes its related disbursements.

## Transaction and recovery concepts

Adding a record uses a single SQLite transaction for the scheme/application/disbursement changes. If an operation fails before commit, the transaction is rolled back rather than leaving a partial submission.

The dashboard also contains educational descriptions of:

- **Shadow Paging** — a database recovery technique explained conceptually.
- **ARIES** — a log-based recovery algorithm with Analysis, Redo, and Undo phases.

**Important accuracy note:** This project uses SQLite's transaction and recovery facilities. It does not implement ARIES or classic Shadow Paging itself, and it does not claim that SQLite internally uses those algorithms. If these algorithms are required for an academic submission, explain them separately in the project report or implement a clearly labelled simulation.

## Sample data

On first launch, the application inserts a small set of sample scholarship schemes, applications, and disbursements, but only when all three database tables are empty. You can add and delete records through the dashboard.

## Limitations

- This is a local educational/demo application, not a production scholarship portal.
- It does not include user authentication, role-based access, online payments, or deployment configuration.
- The sample records are demonstration data, not real student records.

## Future improvements

- Add authentication and user roles.
- Add search, filters, and export to CSV/Excel.
- Add application status tracking and validation rules.
- Add automated tests and deployment instructions.

## Author

Add your name and academic details here before publishing.
